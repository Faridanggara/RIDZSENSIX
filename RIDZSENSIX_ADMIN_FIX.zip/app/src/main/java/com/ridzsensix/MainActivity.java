package com.ridzsensix;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Switch;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.provider.Settings;
import android.net.Uri;
import android.os.Build;
import rikka.shizuku.Shizuku;
import android.content.SharedPreferences;
import android.app.AlertDialog;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {
    private Switch swAim, swHead, swWeapon, swRecoil, swDrag, swHitbox, swSmooth;
    private SeekBar seekSensX, seekSensY;
    private TextView tvSensX, tvSensY;
    private Button btnApply, btnLaunchFF, btnLaunchFFMax, btnAdmin;
    private SharedPreferences prefs;
    private boolean shizukuReady = false;
    private DatabaseHelper db;
    private String currentUser;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("RIDZ_SETTINGS", MODE_PRIVATE);
        db = new DatabaseHelper(this);
        currentUser = getIntent().getStringExtra("email");

        swAim = findViewById(R.id.swAim);
        swHead = findViewById(R.id.swHead);
        swWeapon = findViewById(R.id.swWeapon);
        swRecoil = findViewById(R.id.swRecoil);
        swDrag = findViewById(R.id.swDrag);
        swHitbox = findViewById(R.id.swHitbox);
        swSmooth = findViewById(R.id.swSmooth);
        seekSensX = findViewById(R.id.seekSensX);
        seekSensY = findViewById(R.id.seekSensY);
        tvSensX = findViewById(R.id.tvSensX);
        tvSensY = findViewById(R.id.tvSensY);
        btnApply = findViewById(R.id.btnApply);
        btnLaunchFF = findViewById(R.id.btnLaunchFF);
        btnLaunchFFMax = findViewById(R.id.btnLaunchFFMax);
        btnAdmin = findViewById(R.id.btnAdmin);

        if (currentUser == null || !currentUser.equals("admin@ridz.com")) {
            btnAdmin.setVisibility(Button.GONE);
        } else {
            btnAdmin.setVisibility(Button.VISIBLE);
            btnAdmin.setOnClickListener(v -> showAdminPanel());
        }

        swAim.setChecked(prefs.getBoolean("aim", false));
        swHead.setChecked(prefs.getBoolean("head", false));
        swWeapon.setChecked(prefs.getBoolean("weapon", false));
        swRecoil.setChecked(prefs.getBoolean("recoil", false));
        swDrag.setChecked(prefs.getBoolean("drag", false));
        swHitbox.setChecked(prefs.getBoolean("hitbox", false));
        swSmooth.setChecked(prefs.getBoolean("smooth", false));
        int sensX = prefs.getInt("sensX", 50);
        int sensY = prefs.getInt("sensY", 50);
        seekSensX.setProgress(sensX);
        seekSensY.setProgress(sensY);
        tvSensX.setText(String.valueOf(sensX));
        tvSensY.setText(String.valueOf(sensY));

        seekSensX.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) { tvSensX.setText(String.valueOf(p)); }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });
        seekSensY.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) { tvSensY.setText(String.valueOf(p)); }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });

        if (Shizuku.pingBinder()) shizukuReady = true;
        else Shizuku.requestPermission(0);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                           Uri.parse("package:" + getPackageName())));
            } else {
                startService(new Intent(this, OverlayService.class));
            }
        }

        btnApply.setOnClickListener(v -> {
            if (!shizukuReady) {
                Toast.makeText(this, "⚠️ Shizuku tidak aktif!", Toast.LENGTH_SHORT).show();
                return;
            }
            prefs.edit()
                .putBoolean("aim", swAim.isChecked())
                .putBoolean("head", swHead.isChecked())
                .putBoolean("weapon", swWeapon.isChecked())
                .putBoolean("recoil", swRecoil.isChecked())
                .putBoolean("drag", swDrag.isChecked())
                .putBoolean("hitbox", swHitbox.isChecked())
                .putBoolean("smooth", swSmooth.isChecked())
                .putInt("sensX", seekSensX.getProgress())
                .putInt("sensY", seekSensY.getProgress())
                .apply();
            applySmooth();
            Toast.makeText(this, "✅ Pengaturan tersimpan + Layar licin!", Toast.LENGTH_SHORT).show();
        });

        btnLaunchFF.setOnClickListener(v -> launchGame("com.dts.freefireth"));
        btnLaunchFFMax.setOnClickListener(v -> launchGame("com.dts.freefiremax"));
    }

    private void applySmooth() {
        try {
            String[] cmds = {
                "settings put system pointer_speed 10",
                "settings put global touch_delay 0"
            };
            for (String cmd : cmds) {
                Process p = Runtime.getRuntime().exec(new String[]{"sh", "-c", cmd});
                p.waitFor();
            }
        } catch (Exception e) {}
    }

    private void launchGame(String pkg) {
        try {
            Intent intent = getPackageManager().getLaunchIntentForPackage(pkg);
            if (intent != null) startActivity(intent);
            else Toast.makeText(this, "Game tidak terinstal", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {}
    }

    private void showAdminPanel() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("👑 Admin Panel");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 40, 40, 40);

        Button btnGenerate = new Button(this);
        btnGenerate.setText("🔑 Generate Kode Aktivasi");
        btnGenerate.setOnClickListener(v -> {
            String newCode = db.generateActivationCode();
            if (newCode != null) {
                Toast.makeText(this, "✅ Kode baru: " + newCode, Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "❌ Gagal generate", Toast.LENGTH_SHORT).show();
            }
        });

        Button btnViewCodes = new Button(this);
        btnViewCodes.setText("📋 Lihat Kode Belum Dipakai");
        btnViewCodes.setOnClickListener(v -> {
            String[] codes = db.getUnusedCodes();
            if (codes.length == 0) {
                Toast.makeText(this, "Tidak ada kode tersedia", Toast.LENGTH_SHORT).show();
            } else {
                StringBuilder msg = new StringBuilder();
                msg.append("Kode belum dipakai:
");
                for (String c : codes) {
                    msg.append(c).append("
");
                }
                new AlertDialog.Builder(this)
                    .setTitle("📋 Kode Aktivasi")
                    .setMessage(msg.toString())
                    .setPositiveButton("OK", null)
                    .show();
            }
        });

        layout.addView(btnGenerate);
        layout.addView(btnViewCodes);
        builder.setView(layout);
        builder.setPositiveButton("Tutup", null);
        builder.show();
    }

    @Override protected void onResume() {
        super.onResume();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(this)) {
            startService(new Intent(this, OverlayService.class));
        }
        if (Shizuku.pingBinder()) shizukuReady = true;
    }
}
