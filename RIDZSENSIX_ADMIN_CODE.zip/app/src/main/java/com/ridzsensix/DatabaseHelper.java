package com.ridzsensix;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.Random;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "ridz.db";
    private static final int DB_VERSION = 2;
    private static final String TABLE_ADMINS = "admins";
    private static final String TABLE_CODES = "activation_codes";
    private static final String COL_EMAIL = "email";
    private static final String COL_PASS = "password";
    private static final String COL_CODE = "code";
    private static final String COL_USED = "used";
    private static final String COL_DEVICE = "device_id";

    public DatabaseHelper(Context c) { super(c, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE "+TABLE_ADMINS+"("+COL_EMAIL+" TEXT PRIMARY KEY, "+COL_PASS+" TEXT)");
        db.execSQL("CREATE TABLE "+TABLE_CODES+"("+COL_CODE+" TEXT PRIMARY KEY, "+COL_USED+" INTEGER DEFAULT 0, "+COL_DEVICE+" TEXT)");
        // Admin default
        ContentValues cv = new ContentValues();
        cv.put(COL_EMAIL, "admin@ridz.com");
        cv.put(COL_PASS, "admin123");
        db.insert(TABLE_ADMINS, null, cv);
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {}

    public boolean login(String email, String pass) {
        Cursor c = getReadableDatabase().query(TABLE_ADMINS, null, COL_EMAIL+"=? AND "+COL_PASS+"=?", new String[]{email,pass}, null,null,null);
        boolean ok = c.getCount() > 0;
        c.close();
        return ok;
    }

    public boolean register(String email, String pass) {
        ContentValues cv = new ContentValues();
        cv.put(COL_EMAIL, email);
        cv.put(COL_PASS, pass);
        long result = getWritableDatabase().insert(TABLE_ADMINS, null, cv);
        return result != -1;
    }

    public String generateActivationCode() {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        StringBuilder code = new StringBuilder();
        Random r = new Random();
        for (int i = 0; i < 6; i++) {
            code.append(chars.charAt(r.nextInt(chars.length())));
        }
        String codeStr = code.toString();
        // Simpan kode dengan status unused (0)
        ContentValues cv = new ContentValues();
        cv.put(COL_CODE, codeStr);
        cv.put(COL_USED, 0);
        long result = getWritableDatabase().insert(TABLE_CODES, null, cv);
        if (result != -1) return codeStr;
        return null;
    }

    public boolean isCodeValid(String code) {
        Cursor c = getReadableDatabase().query(TABLE_CODES, null, COL_CODE+"=? AND "+COL_USED+"=0", new String[]{code}, null,null,null);
        boolean valid = c.getCount() > 0;
        c.close();
        return valid;
    }

    public boolean useCode(String code, String deviceId) {
        ContentValues cv = new ContentValues();
        cv.put(COL_USED, 1);
        cv.put(COL_DEVICE, deviceId);
        int rows = getWritableDatabase().update(TABLE_CODES, cv, COL_CODE+"=?", new String[]{code});
        return rows > 0;
    }

    public String[] getUnusedCodes() {
        Cursor c = getReadableDatabase().query(TABLE_CODES, new String[]{COL_CODE}, COL_USED+"=0", null, null, null, null);
        String[] codes = new String[c.getCount()];
        int i = 0;
        while (c.moveToNext()) { codes[i++] = c.getString(0); }
        c.close();
        return codes;
    }
}
