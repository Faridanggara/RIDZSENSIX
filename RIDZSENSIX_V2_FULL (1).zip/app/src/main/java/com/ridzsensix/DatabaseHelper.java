package com.ridzsensix;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "ridz.db";
    private static final int DB_VERSION = 1;
    private static final String TABLE = "admins";
    private static final String COL_EMAIL = "email";
    private static final String COL_PASS = "password";
    public DatabaseHelper(Context c) { super(c, DB_NAME, null, DB_VERSION); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE "+TABLE+"("+COL_EMAIL+" TEXT PRIMARY KEY, "+COL_PASS+" TEXT)");
        ContentValues cv = new ContentValues();
        cv.put(COL_EMAIL, "admin@ridz.com");
        cv.put(COL_PASS, "admin123");
        db.insert(TABLE, null, cv);
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {}
    public boolean login(String email, String pass) {
        Cursor c = getReadableDatabase().query(TABLE, null, COL_EMAIL+"=? AND "+COL_PASS+"=?", new String[]{email,pass}, null,null,null);
        boolean ok = c.getCount() > 0;
        c.close();
        return ok;
    }
    public boolean register(String email, String pass) {
        ContentValues cv = new ContentValues();
        cv.put(COL_EMAIL, email);
        cv.put(COL_PASS, pass);
        long result = getWritableDatabase().insert(TABLE, null, cv);
        return result != -1;
    }
}
