package com.ridzsensix;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.os.IBinder;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.TextView;
public class OverlayService extends Service {
    @Override public IBinder onBind(Intent i) { return null; }
    @Override public void onCreate() {
        super.onCreate();
        TextView tv = new TextView(this);
        tv.setText("+");
        tv.setTextColor(Color.RED);
        tv.setTextSize(50);
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            android.graphics.PixelFormat.TRANSLUCENT
        );
        p.gravity = Gravity.CENTER;
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        wm.addView(tv, p);
    }
}