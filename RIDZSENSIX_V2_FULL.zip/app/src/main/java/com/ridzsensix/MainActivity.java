package com.ridzsensix;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.provider.Settings;
import android.net.Uri;
import android.os.Build;
import rikka.shizuku.Shizuku;
import android.content.SharedPreferences;

public class MainActivity extends AppCompatActivity {
    private Switch swAim, swHead, swWeapon, swRecoil, swSensX, swSensY, swDrag, swHitbox, swSmooth;
    private Button btnApply, btnLaunchFF, btnLaunchFFMax;
    private SharedPreferences prefs;
    private boolean shizukuReady = false;
    private boolean overlayGranted = false;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("RIDZ_SETTINGS", MODE_PRIVATE);

        // Inisialisasi Switch
        swAim = findViewById(R.id.swAim);
        swHead = findViewById(R.id.swHead);
        swWeapon = findViewById(R.id.swWeapon);
        swRecoil = findViewById(R.id.swRecoil);
        swSensX = findViewById(R.id.swSensX);
        swSensY = findViewById(R.id.swSensY);
        swDrag = findViewById(R.id.swDrag);
        swHitbox = findViewById(R.id.swHitbox);
        swSmooth = findViewById(R.id.swSmooth);
        btnApply = findViewById(R.id.btnApply);
        btnLaunchFF = findViewById(R.id.btnLaunchFF);
        btnLaunchFFMax = findViewById(R.id.btnLaunchFFMax);

        // Muat status tersimpan
        swAim.setChecked(prefs.getBoolean("aim", false));
        swHead.setChecked(prefs.getBoolean("head", false));
        swWeapon.setChecked(prefs.getBoolean("weapon", false));
        swRecoil.setChecked(prefs.getBoolean("recoil", false));
        swSensX.setChecked(prefs.getBoolean("sensX", false));
        swSensY.setChecked(prefs.getBoolean("sensY", false));
        swDrag.setChecked(prefs.getBoolean("drag", false));
        swHitbox.setChecked(prefs.getBoolean("hitbox", false));
        swSmooth.setChecked(prefs.getBoolean("smooth", false));

        // Cek Shizuku
        if (Shizuku.pingBinder()) {
            shizukuReady = true;
            Toast.makeText(this, "Shizuku aktif", Toast.LENGTH_SHORT).show();
        } else {
            Shizuku.requestPermission(0);
        }

        // Cek izin overlay
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                           Uri.parse("package:" + getPackageName()));
                startActivity(intent);
                Toast.makeText(this, "Berikan izin Tampil di atas layar", Toast.LENGTH_LONG).show();
            } else {
                overlayGranted = true;
                startService(new Intent(this, OverlayService.class));
            }
        }

        // Tombol Apply
        btnApply.setOnClickListener(v -> {
            if (!shizukuReady) {
                Toast.makeText(this, "⚠️ Shizuku tidak aktif!", Toast.LENGTH_SHORT).show();
                return;
            }
            // Simpan status
            prefs.edit()
                .putBoolean("aim", swAim.isChecked())
                .putBoolean("head", swHead.isChecked())
                .putBoolean("weapon", swWeapon.isChecked())
                .putBoolean("recoil", swRecoil.isChecked())
                .putBoolean("sensX", swSensX.isChecked())
                .putBoolean("sensY", swSensY.isChecked())
                .putBoolean("drag", swDrag.isChecked())
                .putBoolean("hitbox", swHitbox.isChecked())
                .putBoolean("smooth", swSmooth.isChecked())
                .apply();

            // Eksekusi perintah via Shizuku
            applySettings();
            Toast.makeText(this, "✅ Pengaturan diterapkan!", Toast.LENGTH_SHORT).show();
        });

        btnLaunchFF.setOnClickListener(v -> launchGame("com.dts.freefireth"));
        btnLaunchFFMax.setOnClickListener(v -> launchGame("com.dts.freefiremax"));
    }

    private void applySettings() {
        try {
            // Pelicin layar via Shizuku
            String[] cmds = {
                "settings put system pointer_speed 7",
                "settings put global touch_delay 0"
            };
            for (String cmd : cmds) {
                // Eksekusi via Shizuku (di sini kita panggil shell)
                // Karena kita tidak punya akses langsung, gunakan Runtime
                // (Jika Shizuku aktif, perintah sistem akan berjalan)
                try {
                    Runtime.getRuntime().exec(new String[]{"sh", "-c", cmd});
                } catch (Exception e) {}
            }
        } catch (Exception e) {}
    }

    private void launchGame(String pkg) {
        try {
            Intent intent = getPackageManager().getLaunchIntentForPackage(pkg);
            if (intent != null) {
                startActivity(intent);
                Toast.makeText(this, "Launching "+pkg, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Game tidak terinstal", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Error: "+e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (Settings.canDrawOverlays(this) && !overlayGranted) {
                overlayGranted = true;
                startService(new Intent(this, OverlayService.class));
            }
        }
        if (Shizuku.pingBinder()) shizukuReady = true;
    }
}
