package com.ridzsensix;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
public class RegisterActivity extends AppCompatActivity {
    EditText etEmail, etPass, etConfirm;
    Button btnRegister;
    DatabaseHelper db;
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_register);
        db = new DatabaseHelper(this);
        etEmail = findViewById(R.id.etRegEmail);
        etPass = findViewById(R.id.etRegPass);
        etConfirm = findViewById(R.id.etRegConfirm);
        btnRegister = findViewById(R.id.btnRegRegister);
        btnRegister.setOnClickListener(v -> {
            String email = etEmail.getText().toString();
            String pass = etPass.getText().toString();
            String confirm = etConfirm.getText().toString();
            if (!pass.equals(confirm)) {
                Toast.makeText(this, "Password tidak cocok", Toast.LENGTH_SHORT).show();
                return;
            }
            if (db.register(email, pass)) {
                Toast.makeText(this, "Akun berhasil dibuat!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Email sudah terdaftar", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
