package com.ridzsensix;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Switch;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.provider.Settings;
import android.net.Uri;
import android.os.Build;
import rikka.shizuku.Shizuku;
import android.content.SharedPreferences;
import android.app.AlertDialog;
import android.widget.LinearLayout;
import android.animation.ObjectAnimator;
import android.view.animation.AccelerateDecelerateInterpolator;

public class MainActivity extends AppCompatActivity {
    private Switch swAim, swHead, swWeapon, swRecoil, swDrag, swHitbox, swSmooth;
    private SeekBar seekSensX, seekSensY;
    private TextView tvSensX, tvSensY, tvShizukuStatus;
    private Button btnLaunchFF, btnLaunchFFMax, btnAdmin;
    private SharedPreferences prefs;
    private boolean shizukuReady = false;
    private DatabaseHelper db;
    private String currentUser;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("RIDZ_SETTINGS", MODE_PRIVATE);
        db = new DatabaseHelper(this);
        currentUser = getIntent().getStringExtra("email");

        swAim = findViewById(R.id.swAim);
        swHead = findViewById(R.id.swHead);
        swWeapon = findViewById(R.id.swWeapon);
        swRecoil = findViewById(R.id.swRecoil);
        swDrag = findViewById(R.id.swDrag);
        swHitbox = findViewById(R.id.swHitbox);
        swSmooth = findViewById(R.id.swSmooth);
        seekSensX = findViewById(R.id.seekSensX);
        seekSensY = findViewById(R.id.seekSensY);
        tvSensX = findViewById(R.id.tvSensX);
        tvSensY = findViewById(R.id.tvSensY);
        tvShizukuStatus = findViewById(R.id.tvShizukuStatus);
        btnLaunchFF = findViewById(R.id.btnLaunchFF);
        btnLaunchFFMax = findViewById(R.id.btnLaunchFFMax);
        btnAdmin = findViewById(R.id.btnAdmin);

        // Admin Panel (bebas Shizuku)
        if (currentUser == null || !currentUser.equals("admin@ridz.com")) {
            btnAdmin.setVisibility(Button.GONE);
        } else {
            btnAdmin.setVisibility(Button.VISIBLE);
            btnAdmin.setOnClickListener(v -> showAdminPanel());
        }

        // Load saved states
        swAim.setChecked(prefs.getBoolean("aim", false));
        swHead.setChecked(prefs.getBoolean("head", false));
        swWeapon.setChecked(prefs.getBoolean("weapon", false));
        swRecoil.setChecked(prefs.getBoolean("recoil", false));
        swDrag.setChecked(prefs.getBoolean("drag", false));
        swHitbox.setChecked(prefs.getBoolean("hitbox", false));
        swSmooth.setChecked(prefs.getBoolean("smooth", false));
        int sensX = prefs.getInt("sensX", 50);
        int sensY = prefs.getInt("sensY", 50);
        seekSensX.setProgress(sensX);
        seekSensY.setProgress(sensY);
        tvSensX.setText(String.valueOf(sensX));
        tvSensY.setText(String.valueOf(sensY));

        // Shizuku check
        updateShizukuStatus();

        if (Shizuku.pingBinder()) shizukuReady = true;
        else Shizuku.requestPermission(0);

        // Overlay permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                           Uri.parse("package:" + getPackageName())));
            } else {
                startService(new Intent(this, OverlayService.class));
            }
        }

        // ===== 7 Switch REAL (WAJIB Shizuku) =====
        swAim.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (!shizukuReady) {
                Toast.makeText(this, "⚠️ Shizuku tidak aktif!", Toast.LENGTH_SHORT).show();
                buttonView.setChecked(!isChecked);
                return;
            }
            int speed = isChecked ? 10 : 0;
            runCommand("settings put system pointer_speed " + speed);
            Toast.makeText(this, "Aim Assist: " + (isChecked ? "ON (speed 10)" : "OFF (speed 0)"), Toast.LENGTH_SHORT).show();
            prefs.edit().putBoolean("aim", isChecked).apply();
            animateSwitch(buttonView);
        });

        swHead.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (!shizukuReady) {
                Toast.makeText(this, "⚠️ Shizuku tidak aktif!", Toast.LENGTH_SHORT).show();
                buttonView.setChecked(!isChecked);
                return;
            }
            int delay = isChecked ? 0 : 10;
            runCommand("settings put global touch_delay " + delay);
            Toast.makeText(this, "Headshot: " + (isChecked ? "ON (delay 0)" : "OFF (delay 10)"), Toast.LENGTH_SHORT).show();
            prefs.edit().putBoolean("head", isChecked).apply();
            animateSwitch(buttonView);
        });

        swWeapon.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (!shizukuReady) {
                Toast.makeText(this, "⚠️ Shizuku tidak aktif!", Toast.LENGTH_SHORT).show();
                buttonView.setChecked(!isChecked);
                return;
            }
            int speed = isChecked ? 7 : 3;
            runCommand("settings put system pointer_speed " + speed);
            Toast.makeText(this, "Weapon Config: " + (isChecked ? "ON (speed 7)" : "OFF (speed 3)"), Toast.LENGTH_SHORT).show();
            prefs.edit().putBoolean("weapon", isChecked).apply();
            animateSwitch(buttonView);
        });

        swRecoil.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (!shizukuReady) {
                Toast.makeText(this, "⚠️ Shizuku tidak aktif!", Toast.LENGTH_SHORT).show();
                buttonView.setChecked(!isChecked);
                return;
            }
            int delay = isChecked ? 2 : 8;
            runCommand("settings put global touch_delay " + delay);
            Toast.makeText(this, "Recoil: " + (isChecked ? "ON (delay 2)" : "OFF (delay 8)"), Toast.LENGTH_SHORT).show();
            prefs.edit().putBoolean("recoil", isChecked).apply();
            animateSwitch(buttonView);
        });

        swDrag.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (!shizukuReady) {
                Toast.makeText(this, "⚠️ Shizuku tidak aktif!", Toast.LENGTH_SHORT).show();
                buttonView.setChecked(!isChecked);
                return;
            }
            int speed = isChecked ? 5 : 2;
            runCommand("settings put system pointer_speed " + speed);
            Toast.makeText(this, "DragShot: " + (isChecked ? "ON (speed 5)" : "OFF (speed 2)"), Toast.LENGTH_SHORT).show();
            prefs.edit().putBoolean("drag", isChecked).apply();
            animateSwitch(buttonView);
        });

        swHitbox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (!shizukuReady) {
                Toast.makeText(this, "⚠️ Shizuku tidak aktif!", Toast.LENGTH_SHORT).show();
                buttonView.setChecked(!isChecked);
                return;
            }
            int delay = isChecked ? 4 : 6;
            runCommand("settings put global touch_delay " + delay);
            Toast.makeText(this, "HitBox+: " + (isChecked ? "ON (delay 4)" : "OFF (delay 6)"), Toast.LENGTH_SHORT).show();
            prefs.edit().putBoolean("hitbox", isChecked).apply();
            animateSwitch(buttonView);
        });

        swSmooth.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (!shizukuReady) {
                Toast.makeText(this, "⚠️ Shizuku tidak aktif!", Toast.LENGTH_SHORT).show();
                buttonView.setChecked(!isChecked);
                return;
            }
            int speed = isChecked ? 8 : 4;
            runCommand("settings put system pointer_speed " + speed);
            Toast.makeText(this, "Smooth Aim: " + (isChecked ? "ON (speed 8)" : "OFF (speed 4)"), Toast.LENGTH_SHORT).show();
            prefs.edit().putBoolean("smooth", isChecked).apply();
            animateSwitch(buttonView);
        });

        // ===== Slider Sensitivitas =====
        seekSensX.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                tvSensX.setText(String.valueOf(p));
                if (fromUser && shizukuReady) {
                    int speed = p / 10;
                    runCommand("settings put system pointer_speed " + speed);
                    prefs.edit().putInt("sensX", p).apply();
                }
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });

        seekSensY.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                tvSensY.setText(String.valueOf(p));
                if (fromUser && shizukuReady) {
                    int delay = (100 - p) / 10;
                    runCommand("settings put global touch_delay " + delay);
                    prefs.edit().putInt("sensY", p).apply();
                }
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });

        // ===== Launch FF (dengan deteksi instalasi) =====
        btnLaunchFF.setOnClickListener(v -> launchGame("com.dts.freefireth"));
        btnLaunchFFMax.setOnClickListener(v -> launchGame("com.dts.freefiremax"));
    }

    private void updateShizukuStatus() {
        if (Shizuku.pingBinder()) {
            tvShizukuStatus.setText("🟢 Shizuku: AKTIF");
            tvShizukuStatus.setTextColor(0xFF00CC44);
        } else {
            tvShizukuStatus.setText("🔴 Shizuku: TIDAK AKTIF");
            tvShizukuStatus.setTextColor(0xFFFF0000);
        }
    }

    private void animateSwitch(Switch sw) {
        ObjectAnimator anim = ObjectAnimator.ofFloat(sw, "scaleX", 1f, 1.2f, 1f);
        anim.setDuration(300);
        anim.setInterpolator(new AccelerateDecelerateInterpolator());
        anim.start();
        ObjectAnimator animY = ObjectAnimator.ofFloat(sw, "scaleY", 1f, 0.8f, 1f);
        animY.setDuration(300);
        animY.setInterpolator(new AccelerateDecelerateInterpolator());
        animY.start();
    }

    private void runCommand(String cmd) {
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"sh", "-c", cmd});
            p.waitFor();
        } catch (Exception e) {
            Toast.makeText(this, "Gagal: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void launchGame(String pkg) {
        try {
            PackageManager pm = getPackageManager();
            Intent intent = pm.getLaunchIntentForPackage(pkg);
            if (intent != null) {
                startActivity(intent);
                Toast.makeText(this, "Launching " + pkg, Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "❌ " + pkg + " tidak terinstal!", Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void showAdminPanel() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("👑 Admin Panel");
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 40, 40, 40);

        Button btnGenerate = new Button(this);
        btnGenerate.setText("🔑 Generate Kode Aktivasi");
        btnGenerate.setOnClickListener(v -> {
            String newCode = db.generateActivationCode();
            if (newCode != null) {
                Toast.makeText(this, "✅ Kode baru: " + newCode, Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "❌ Gagal generate", Toast.LENGTH_SHORT).show();
            }
        });

        Button btnViewCodes = new Button(this);
        btnViewCodes.setText("📋 Lihat Kode Belum Dipakai");
        btnViewCodes.setOnClickListener(v -> {
            String[] codes = db.getUnusedCodes();
            if (codes.length == 0) {
                Toast.makeText(this, "Tidak ada kode tersedia", Toast.LENGTH_SHORT).show();
            } else {
                StringBuilder msg = new StringBuilder();
                msg.append("Kode belum dipakai:
");
                for (String c : codes) msg.append(c).append("
");
                new AlertDialog.Builder(this)
                    .setTitle("📋 Kode Aktivasi")
                    .setMessage(msg.toString())
                    .setPositiveButton("OK", null)
                    .show();
            }
        });

        Button btnLogout = new Button(this);
        btnLogout.setText("🚪 Logout");
        btnLogout.setOnClickListener(v -> {
            finish();
            startActivity(new Intent(this, LoginActivity.class));
        });

        layout.addView(btnGenerate);
        layout.addView(btnViewCodes);
        layout.addView(btnLogout);
        builder.setView(layout);
        builder.setPositiveButton("Tutup", null);
        builder.show();
    }

    @Override protected void onResume() {
        super.onResume();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(this)) {
            startService(new Intent(this, OverlayService.class));
        }
        if (Shizuku.pingBinder()) shizukuReady = true;
        updateShizukuStatus();
    }
}
