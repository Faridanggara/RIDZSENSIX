package com.ridzsensix;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        TextView tv = new TextView(this);
        tv.setText("RIDZSENSIX V2\nBERHASIL!");
        tv.setTextColor(0xFFFF0000);
        tv.setTextSize(40);
        tv.setBackgroundColor(0xFF000000);
        tv.setGravity(17);
        setContentView(tv);
    }
}
