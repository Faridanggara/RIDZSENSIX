package com.ridzsensix;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.provider.Settings;
import android.app.AlertDialog;
import android.widget.TextView;
import rikka.shizuku.Shizuku;

public class LoginActivity extends AppCompatActivity {
    EditText etEmail, etPass;
    Button btnLogin, btnRegister;
    DatabaseHelper db;
    SharedPreferences prefs;
    String deviceId;
    TextView tvShizukuStatus;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_login);
        db = new DatabaseHelper(this);
        prefs = getSharedPreferences("RIDZ_DEVICE", MODE_PRIVATE);
        deviceId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        tvShizukuStatus = findViewById(R.id.tvShizukuStatus);

        // Cek Shizuku
        updateShizukuStatus();

        String savedId = prefs.getString("registered_device", "");
        if (!savedId.equals("") && !savedId.equals(deviceId)) {
            showActivationDialog();
            return;
        } else if (savedId.equals("")) {
            prefs.edit().putString("registered_device", deviceId).apply();
        }

        etEmail = findViewById(R.id.etEmail);
        etPass = findViewById(R.id.etPass);
        btnLogin = findViewById(R.id.btnLogin);
        btnRegister = findViewById(R.id.btnRegister);

        btnLogin.setOnClickListener(v -> {
            String email = etEmail.getText().toString();
            String pass = etPass.getText().toString();
            if (db.login(email, pass)) {
                Toast.makeText(this, "Login berhasil!", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(this, MainActivity.class);
                i.putExtra("email", email);
                startActivity(i);
                finish();
            } else {
                Toast.makeText(this, "Email/Password salah", Toast.LENGTH_SHORT).show();
            }
        });
        btnRegister.setOnClickListener(v -> startActivity(new Intent(this, RegisterActivity.class)));
    }

    private void updateShizukuStatus() {
        if (Shizuku.pingBinder()) {
            tvShizukuStatus.setText("🟢 Shizuku: AKTIF");
            tvShizukuStatus.setTextColor(0xFF00CC44);
        } else {
            tvShizukuStatus.setText("🔴 Shizuku: TIDAK AKTIF");
            tvShizukuStatus.setTextColor(0xFFFF0000);
        }
    }

    private void showActivationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("🔑 Aktivasi Perangkat");
        builder.setMessage("Masukkan kode aktivasi dari admin.");
        final EditText input = new EditText(this);
        input.setHint("Kode (6 karakter)");
        builder.setView(input);
        builder.setPositiveButton("Aktivasi", (dialog, which) -> {
            String code = input.getText().toString().toUpperCase().trim();
            if (db.isCodeValid(code)) {
                db.useCode(code, deviceId);
                prefs.edit().putString("registered_device", deviceId).apply();
                Toast.makeText(LoginActivity.this, "✅ Aktivasi berhasil!", Toast.LENGTH_SHORT).show();
                recreate();
            } else {
                Toast.makeText(LoginActivity.this, "❌ Kode tidak valid atau sudah dipakai!", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("Keluar", (dialog, which) -> finish());
        builder.setCancelable(false);
        builder.show();
    }

    @Override protected void onResume() {
        super.onResume();
        updateShizukuStatus();
    }
}
