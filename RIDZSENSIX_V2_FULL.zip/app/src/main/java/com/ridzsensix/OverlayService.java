package com.ridzsensix;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.os.IBinder;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;
public class OverlayService extends Service {
    private WindowManager wm;
    private TextView crosshair;
    @Override public IBinder onBind(Intent i) { return null; }
    @Override public void onCreate() {
        super.onCreate();
        try {
            wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            crosshair = new TextView(this);
            crosshair.setText("+");
            crosshair.setTextColor(Color.RED);
            crosshair.setTextSize(50);
            WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                android.graphics.PixelFormat.TRANSLUCENT
            );
            p.gravity = Gravity.CENTER;
            wm.addView(crosshair, p);
        } catch (Exception e) {
            Toast.makeText(this, "Izin overlay belum diberikan", Toast.LENGTH_SHORT).show();
        }
    }
    @Override public void onDestroy() {
        if (crosshair != null && wm != null) {
            try { wm.removeView(crosshair); } catch (Exception e) {}
        }
        super.onDestroy();
    }
}
