package com.ridzsensix;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.provider.Settings;
import android.net.Uri;
import android.os.Build;
import rikka.shizuku.Shizuku;
import android.content.SharedPreferences;
public class MainActivity extends AppCompatActivity {
    private Switch swAim, swHead, swWeapon, swRecoil, swSensX, swSensY, swDrag, swHitbox, swSmooth;
    private Button btnApply, btnLaunchFF, btnLaunchFFMax;
    private SharedPreferences prefs;
    private boolean shizukuReady = false;
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("RIDZ_SETTINGS", MODE_PRIVATE);
        swAim = findViewById(R.id.swAim);
        swHead = findViewById(R.id.swHead);
        swWeapon = findViewById(R.id.swWeapon);
        swRecoil = findViewById(R.id.swRecoil);
        swSensX = findViewById(R.id.swSensX);
        swSensY = findViewById(R.id.swSensY);
        swDrag = findViewById(R.id.swDrag);
        swHitbox = findViewById(R.id.swHitbox);
        swSmooth = findViewById(R.id.swSmooth);
        btnApply = findViewById(R.id.btnApply);
        btnLaunchFF = findViewById(R.id.btnLaunchFF);
        btnLaunchFFMax = findViewById(R.id.btnLaunchFFMax);
        // Muat status
        swAim.setChecked(prefs.getBoolean("aim", false));
        swHead.setChecked(prefs.getBoolean("head", false));
        swWeapon.setChecked(prefs.getBoolean("weapon", false));
        swRecoil.setChecked(prefs.getBoolean("recoil", false));
        swSensX.setChecked(prefs.getBoolean("sensX", false));
        swSensY.setChecked(prefs.getBoolean("sensY", false));
        swDrag.setChecked(prefs.getBoolean("drag", false));
        swHitbox.setChecked(prefs.getBoolean("hitbox", false));
        swSmooth.setChecked(prefs.getBoolean("smooth", false));
        if (Shizuku.pingBinder()) { shizukuReady = true; }
        else { Shizuku.requestPermission(0); }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())));
        }
        btnApply.setOnClickListener(v -> {
            if (!shizukuReady) { Toast.makeText(this, "⚠️ Shizuku tidak aktif!", Toast.LENGTH_SHORT).show(); return; }
            prefs.edit()
                .putBoolean("aim", swAim.isChecked())
                .putBoolean("head", swHead.isChecked())
                .putBoolean("weapon", swWeapon.isChecked())
                .putBoolean("recoil", swRecoil.isChecked())
                .putBoolean("sensX", swSensX.isChecked())
                .putBoolean("sensY", swSensY.isChecked())
                .putBoolean("drag", swDrag.isChecked())
                .putBoolean("hitbox", swHitbox.isChecked())
                .putBoolean("smooth", swSmooth.isChecked())
                .apply();
            Toast.makeText(this, "✅ Pengaturan diterapkan!", Toast.LENGTH_SHORT).show();
        });
        btnLaunchFF.setOnClickListener(v -> launchGame("com.dts.freefireth"));
        btnLaunchFFMax.setOnClickListener(v -> launchGame("com.dts.freefiremax"));
    }
    private void launchGame(String pkg) {
        try {
            Intent intent = getPackageManager().getLaunchIntentForPackage(pkg);
            if (intent != null) startActivity(intent);
            else Toast.makeText(this, "Game tidak terinstal", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {}
    }
}
